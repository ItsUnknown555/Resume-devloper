import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// This is primarily a client-side application, but including the schema
// for type consistency throughout the app
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Database table for storing resumes
export const resumes = pgTable("resumes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  title: text("title").notNull(),
  data: jsonb("data").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertResumeSchema = createInsertSchema(resumes)
  .omit({ id: true, createdAt: true, updatedAt: true });

export type InsertResume = z.infer<typeof insertResumeSchema>;
export type ResumeRecord = typeof resumes.$inferSelect;

// Resume data schemas for client-side
export const resumeSchema = z.object({
  personalDetails: z.object({
    name: z.string().min(1, "Name is required"),
    email: z.string().email("Invalid email address"),
    phone: z.string().optional(),
    photo: z.string().optional(),
    title: z.string().optional(),
    address: z.string().optional(),
    summary: z.string().optional(),
  }),
  education: z.array(
    z.object({
      id: z.string(),
      institution: z.string().optional(),
      degree: z.string().optional(),
      fieldOfStudy: z.string().optional(),
      startDate: z.string().optional(),
      endDate: z.string().optional(),
      description: z.string().optional(),
    })
  ),
  experience: z.array(
    z.object({
      id: z.string(),
      company: z.string().optional(),
      position: z.string().optional(),
      location: z.string().optional(),
      startDate: z.string().optional(),
      endDate: z.string().optional(),
      description: z.string().optional(),
    })
  ),
  skills: z.array(
    z.object({
      id: z.string(),
      name: z.string().optional(),
      level: z.number().min(0).max(100).optional(),
    })
  ),
  languages: z.array(
    z.object({
      id: z.string(),
      name: z.string().optional(),
      proficiency: z.string().optional(),
    })
  ),
  socialLinks: z.array(
    z.object({
      id: z.string(),
      platform: z.string().optional(),
      url: z.string().optional(),
    })
  ),
});

export type Resume = z.infer<typeof resumeSchema>;
