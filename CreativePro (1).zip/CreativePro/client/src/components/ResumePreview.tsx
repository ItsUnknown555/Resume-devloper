import { useContext } from "react";
import { ResumeContext, SettingsContext } from "@/App";
import MinimalistTemplate from "./templates/MinimalistTemplate";
import ModernTemplate from "./templates/ModernTemplate";
import ClassicTemplate from "./templates/ClassicTemplate";

export default function ResumePreview() {
  const { resumeData } = useContext(ResumeContext);
  const { settings } = useContext(SettingsContext);

  // Generate font style based on settings
  const fontStyle = {
    fontFamily: settings.font,
    "--primary-color": settings.primaryColor,
    fontSize: settings.fontSize === "small" ? "0.9rem" : 
              settings.fontSize === "large" ? "1.1rem" : "1rem"
  } as React.CSSProperties;

  const renderTemplate = () => {
    switch (settings.template) {
      case "minimalist":
        return <MinimalistTemplate resume={resumeData} />;
      case "modern":
        return <ModernTemplate resume={resumeData} />;
      case "classic":
        return <ClassicTemplate resume={resumeData} />;
      default:
        return <MinimalistTemplate resume={resumeData} />;
    }
  };

  return (
    <div 
      className="w-full bg-white shadow-none print:shadow-none overflow-hidden"
      style={fontStyle}
    >
      {renderTemplate()}
    </div>
  );
}
