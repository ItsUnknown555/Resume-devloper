import { Resume } from "@shared/schema";
import { AtSign, Phone, MapPin, Globe, Library, Briefcase, Award, MessageSquare } from "lucide-react";

interface MinimalistTemplateProps {
  resume: Resume;
}

export default function MinimalistTemplate({ resume }: MinimalistTemplateProps) {
  const { personalDetails, education, experience, skills, languages, socialLinks } = resume;

  // Handle empty state with clean layout
  const hasPhoto = Boolean(personalDetails.photo);
  const hasSummary = Boolean(personalDetails.summary);
  const hasEducation = education && education.length > 0;
  const hasExperience = experience && experience.length > 0;
  const hasSkills = skills && skills.length > 0;
  const hasLanguages = languages && languages.length > 0;
  const hasSocialLinks = socialLinks && socialLinks.length > 0;

  return (
    <div className="min-w-[740px] max-w-[800px] mx-auto bg-white">
      {/* Header */}
      <header className="p-8 pb-6">
        <div className="flex items-start justify-between">
          <div className={`${hasPhoto ? 'w-3/4 pr-6' : 'w-full'}`}>
            <h1 className="text-3xl font-bold mb-1" style={{ color: 'var(--primary-color)' }}>
              {personalDetails.name || "Your Name"}
            </h1>
            <h2 className="text-xl text-gray-600 mb-4">
              {personalDetails.title || "Professional Title"}
            </h2>
            
            {hasSummary && (
              <p className="text-gray-700 mb-4 leading-relaxed">
                {personalDetails.summary}
              </p>
            )}
            
            <div className="flex flex-wrap gap-4 text-sm text-gray-600">
              {personalDetails.email && (
                <div className="flex items-center gap-1">
                  <AtSign className="w-4 h-4" style={{ color: 'var(--primary-color)' }} />
                  <span>{personalDetails.email}</span>
                </div>
              )}
              
              {personalDetails.phone && (
                <div className="flex items-center gap-1">
                  <Phone className="w-4 h-4" style={{ color: 'var(--primary-color)' }} />
                  <span>{personalDetails.phone}</span>
                </div>
              )}
              
              {personalDetails.address && (
                <div className="flex items-center gap-1">
                  <MapPin className="w-4 h-4" style={{ color: 'var(--primary-color)' }} />
                  <span>{personalDetails.address}</span>
                </div>
              )}
            </div>
          </div>
          
          {hasPhoto && (
            <div className="w-1/4 flex justify-end">
              <img 
                src={personalDetails.photo} 
                alt={personalDetails.name || "Profile"} 
                className="w-32 h-32 rounded-full object-cover border-4"
                style={{ borderColor: 'var(--primary-color)' }}
              />
            </div>
          )}
        </div>
      </header>
      
      <div className="px-8">
        <hr className="border-gray-200" />
      </div>
      
      <main className="p-8 pt-6 grid grid-cols-3 gap-6">
        <div className="col-span-2">
          {/* Experience Section */}
          {hasExperience && (
            <section className="mb-6">
              <h3 className="text-lg font-semibold flex items-center gap-2 mb-4" style={{ color: 'var(--primary-color)' }}>
                <Briefcase className="w-5 h-5" /> 
                Work Experience
              </h3>
              
              <div className="space-y-4">
                {experience.map((exp) => (
                  <div key={exp.id} className="mb-4">
                    <div className="flex justify-between items-start">
                      <h4 className="font-medium">{exp.position || "Position"}</h4>
                      <div className="text-sm text-gray-500">
                        {exp.startDate && exp.endDate ? `${exp.startDate} - ${exp.endDate}` : 
                         exp.startDate ? `${exp.startDate} - Present` : ""}
                      </div>
                    </div>
                    <div className="text-gray-600 font-medium">{exp.company || "Company"}</div>
                    {exp.location && (
                      <div className="text-sm text-gray-500 mb-2">{exp.location}</div>
                    )}
                    {exp.description && (
                      <p className="text-sm text-gray-700 whitespace-pre-line">{exp.description}</p>
                    )}
                  </div>
                ))}
              </div>
            </section>
          )}
          
          {/* Education Section */}
          {hasEducation && (
            <section className="mb-6">
              <h3 className="text-lg font-semibold flex items-center gap-2 mb-4" style={{ color: 'var(--primary-color)' }}>
                <Library className="w-5 h-5" /> 
                Education
              </h3>
              
              <div className="space-y-4">
                {education.map((edu) => (
                  <div key={edu.id} className="mb-4">
                    <div className="flex justify-between items-start">
                      <h4 className="font-medium">{edu.degree || "Degree"}</h4>
                      <div className="text-sm text-gray-500">
                        {edu.startDate && edu.endDate ? `${edu.startDate} - ${edu.endDate}` : 
                         edu.startDate ? `${edu.startDate} - Present` : ""}
                      </div>
                    </div>
                    <div className="text-gray-600 font-medium">{edu.institution || "Institution"}</div>
                    {edu.fieldOfStudy && (
                      <div className="text-sm text-gray-500 mb-2">{edu.fieldOfStudy}</div>
                    )}
                    {edu.description && (
                      <p className="text-sm text-gray-700 whitespace-pre-line">{edu.description}</p>
                    )}
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>
        
        <div className="col-span-1">
          {/* Skills Section */}
          {hasSkills && (
            <section className="mb-6">
              <h3 className="text-lg font-semibold flex items-center gap-2 mb-4" style={{ color: 'var(--primary-color)' }}>
                <Award className="w-5 h-5" /> 
                Skills
              </h3>
              
              <div className="space-y-2">
                {skills.map((skill) => (
                  <div key={skill.id} className="mb-2">
                    <div className="flex justify-between mb-1">
                      <span className="text-gray-700">{skill.name || "Skill"}</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-1.5">
                      <div 
                        className="h-1.5 rounded-full" 
                        style={{ 
                          width: `${skill.level || 0}%`,
                          backgroundColor: 'var(--primary-color)' 
                        }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}
          
          {/* Languages Section */}
          {hasLanguages && (
            <section className="mb-6">
              <h3 className="text-lg font-semibold flex items-center gap-2 mb-4" style={{ color: 'var(--primary-color)' }}>
                <MessageSquare className="w-5 h-5" /> 
                Languages
              </h3>
              
              <ul className="space-y-2">
                {languages.map((language) => (
                  <li key={language.id} className="flex justify-between items-center">
                    <span className="text-gray-700">{language.name || "Language"}</span>
                    <span className="text-sm text-gray-500">{language.proficiency || "Level"}</span>
                  </li>
                ))}
              </ul>
            </section>
          )}
          
          {/* Social Links */}
          {hasSocialLinks && (
            <section className="mb-6">
              <h3 className="text-lg font-semibold flex items-center gap-2 mb-4" style={{ color: 'var(--primary-color)' }}>
                <Globe className="w-5 h-5" /> 
                Links
              </h3>
              
              <ul className="space-y-2">
                {socialLinks.map((link) => (
                  <li key={link.id} className="text-gray-700 break-all">
                    <div className="font-medium">{link.platform || "Platform"}</div>
                    <a 
                      href={link.url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-sm hover:underline"
                      style={{ color: 'var(--primary-color)' }}
                    >
                      {link.url || "URL"}
                    </a>
                  </li>
                ))}
              </ul>
            </section>
          )}
        </div>
      </main>
    </div>
  );
}
