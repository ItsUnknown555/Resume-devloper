import { Resume } from "@shared/schema";

interface ClassicTemplateProps {
  resume: Resume;
}

export default function ClassicTemplate({ resume }: ClassicTemplateProps) {
  const { personalDetails, education, experience, skills, languages, socialLinks } = resume;

  // Handle empty states
  const hasPhoto = Boolean(personalDetails.photo);
  const hasSummary = Boolean(personalDetails.summary);
  const hasEducation = education && education.length > 0;
  const hasExperience = experience && experience.length > 0;
  const hasSkills = skills && skills.length > 0;
  const hasLanguages = languages && languages.length > 0;
  const hasSocialLinks = socialLinks && socialLinks.length > 0;

  return (
    <div className="min-w-[740px] max-w-[800px] mx-auto bg-white">
      {/* Header */}
      <header className="text-center py-6 border-b-2 border-gray-300">
        <h1 className="text-3xl font-bold uppercase tracking-wider mb-1" style={{ color: 'var(--primary-color)' }}>
          {personalDetails.name || "Your Name"}
        </h1>
        {personalDetails.title && (
          <h2 className="text-xl text-gray-700 mb-4">
            {personalDetails.title}
          </h2>
        )}
        
        <div className="flex justify-center flex-wrap gap-4 text-sm text-gray-600">
          {personalDetails.email && (
            <div>
              <span className="font-semibold">Email:</span> {personalDetails.email}
            </div>
          )}
          
          {personalDetails.phone && (
            <div>
              <span className="font-semibold">Phone:</span> {personalDetails.phone}
            </div>
          )}
          
          {personalDetails.address && (
            <div>
              <span className="font-semibold">Address:</span> {personalDetails.address}
            </div>
          )}
        </div>
      </header>
      
      {/* Profile Photo - Classic places it below the header */}
      {hasPhoto && (
        <div className="flex justify-center -mt-6">
          <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-white shadow-lg bg-white">
            <img 
              src={personalDetails.photo} 
              alt={personalDetails.name || "Profile"} 
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      )}
      
      <main className="p-8">
        {/* Summary Section */}
        {hasSummary && (
          <section className="mb-6">
            <h3 className="text-lg font-bold uppercase mb-3 pb-1 border-b" style={{ color: 'var(--primary-color)' }}>
              Professional Summary
            </h3>
            <p className="text-gray-700 leading-relaxed">
              {personalDetails.summary}
            </p>
          </section>
        )}
        
        {/* Experience Section */}
        {hasExperience && (
          <section className="mb-6">
            <h3 className="text-lg font-bold uppercase mb-3 pb-1 border-b" style={{ color: 'var(--primary-color)' }}>
              Work Experience
            </h3>
            
            <div className="space-y-4">
              {experience.map((exp) => (
                <div key={exp.id} className="mb-4">
                  <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-1">
                    <h4 className="font-bold text-gray-800">{exp.position || "Position"}</h4>
                    <div className="text-sm font-semibold text-gray-600">
                      {exp.startDate && exp.endDate ? `${exp.startDate} - ${exp.endDate}` : 
                       exp.startDate ? `${exp.startDate} - Present` : ""}
                    </div>
                  </div>
                  <div className="text-gray-700 font-semibold mb-1">
                    {exp.company || "Company"}
                    {exp.location && <span className="font-normal"> • {exp.location}</span>}
                  </div>
                  {exp.description && (
                    <p className="text-sm text-gray-700 whitespace-pre-line mt-2">{exp.description}</p>
                  )}
                </div>
              ))}
            </div>
          </section>
        )}
        
        {/* Education Section */}
        {hasEducation && (
          <section className="mb-6">
            <h3 className="text-lg font-bold uppercase mb-3 pb-1 border-b" style={{ color: 'var(--primary-color)' }}>
              Education
            </h3>
            
            <div className="space-y-4">
              {education.map((edu) => (
                <div key={edu.id} className="mb-4">
                  <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-1">
                    <h4 className="font-bold text-gray-800">{edu.degree || "Degree"}</h4>
                    <div className="text-sm font-semibold text-gray-600">
                      {edu.startDate && edu.endDate ? `${edu.startDate} - ${edu.endDate}` : 
                       edu.startDate ? `${edu.startDate} - Present` : ""}
                    </div>
                  </div>
                  <div className="text-gray-700 font-semibold mb-1">
                    {edu.institution || "Institution"}
                    {edu.fieldOfStudy && <span className="font-normal"> • {edu.fieldOfStudy}</span>}
                  </div>
                  {edu.description && (
                    <p className="text-sm text-gray-700 whitespace-pre-line mt-2">{edu.description}</p>
                  )}
                </div>
              ))}
            </div>
          </section>
        )}
        
        {/* Two Column Layout for Skills, Languages, and Links */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Skills Section */}
          {hasSkills && (
            <section>
              <h3 className="text-lg font-bold uppercase mb-3 pb-1 border-b" style={{ color: 'var(--primary-color)' }}>
                Skills
              </h3>
              
              <div className="flex flex-wrap gap-2">
                {skills.map((skill) => (
                  <span 
                    key={skill.id} 
                    className="px-3 py-1 rounded-full text-sm"
                    style={{ 
                      backgroundColor: skill.level && skill.level > 70 ? 'var(--primary-color)' : '#f3f4f6',
                      color: skill.level && skill.level > 70 ? 'white' : 'black'
                    }}
                  >
                    {skill.name || "Skill"}
                  </span>
                ))}
              </div>
            </section>
          )}
          
          {/* Languages Section */}
          {hasLanguages && (
            <section>
              <h3 className="text-lg font-bold uppercase mb-3 pb-1 border-b" style={{ color: 'var(--primary-color)' }}>
                Languages
              </h3>
              
              <ul className="list-disc list-inside space-y-1">
                {languages.map((language) => (
                  <li key={language.id} className="text-gray-700">
                    <span className="font-medium">{language.name || "Language"}</span>
                    {language.proficiency && (
                      <span className="text-gray-500"> - {language.proficiency}</span>
                    )}
                  </li>
                ))}
              </ul>
            </section>
          )}
        </div>
        
        {/* Social Links - Always Full Width */}
        {hasSocialLinks && (
          <section className="mt-6 pt-4 border-t border-gray-200">
            <h3 className="text-lg font-bold uppercase mb-3 pb-1 border-b" style={{ color: 'var(--primary-color)' }}>
              Links
            </h3>
            
            <div className="flex flex-wrap gap-4">
              {socialLinks.map((link) => (
                <a 
                  key={link.id}
                  href={link.url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center text-sm hover:underline font-medium"
                  style={{ color: 'var(--primary-color)' }}
                >
                  {link.platform || "Platform"}: 
                  <span className="ml-1 font-normal break-all">{link.url || "URL"}</span>
                </a>
              ))}
            </div>
          </section>
        )}
      </main>
    </div>
  );
}
