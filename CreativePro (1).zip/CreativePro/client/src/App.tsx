import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import { createContext, useState, useEffect } from "react";
import { Resume } from "@shared/schema";
import { 
  DEFAULT_RESUME_DATA, 
  DEFAULT_SETTINGS, 
  loadResumeFromStorage, 
  loadSettingsFromStorage,
  saveResumeToStorage,
  saveSettingsToStorage
} from "@/lib/utils";
import { ResumeSettings, SettingsState } from "@/lib/types";

// Create Resume Context
export const ResumeContext = createContext<{
  resumeData: Resume;
  setResumeData: React.Dispatch<React.SetStateAction<Resume>>;
}>({
  resumeData: DEFAULT_RESUME_DATA,
  setResumeData: () => {},
});

// Create Settings Context
export const SettingsContext = createContext<SettingsState>({
  settings: DEFAULT_SETTINGS,
  setSettings: () => {},
});

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [resumeData, setResumeData] = useState<Resume>(DEFAULT_RESUME_DATA);
  const [settings, setSettings] = useState<ResumeSettings>(DEFAULT_SETTINGS);

  // Load resume data and settings from localStorage on initial load
  useEffect(() => {
    const savedResume = loadResumeFromStorage();
    if (savedResume) {
      setResumeData(savedResume);
    }

    const savedSettings = loadSettingsFromStorage();
    if (savedSettings) {
      setSettings(savedSettings);
    }
  }, []);

  // Save resume data to localStorage whenever it changes
  useEffect(() => {
    saveResumeToStorage(resumeData);
  }, [resumeData]);

  // Save settings to localStorage whenever they change
  useEffect(() => {
    saveSettingsToStorage(settings);
  }, [settings]);

  return (
    <QueryClientProvider client={queryClient}>
      <ResumeContext.Provider value={{ resumeData, setResumeData }}>
        <SettingsContext.Provider value={{ settings, setSettings }}>
          <Router />
          <Toaster />
        </SettingsContext.Provider>
      </ResumeContext.Provider>
    </QueryClientProvider>
  );
}

export default App;
