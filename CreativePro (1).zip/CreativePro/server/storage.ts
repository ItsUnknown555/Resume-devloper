import { users, resumes, type User, type InsertUser, type Resume, type InsertResume, type ResumeRecord } from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

// Storage interface for application
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Resume methods
  getResume(id: number): Promise<ResumeRecord | undefined>;
  getResumesByUserId(userId: number): Promise<ResumeRecord[]>;
  createResume(resume: InsertResume): Promise<ResumeRecord>;
  updateResume(id: number, data: Partial<Resume>): Promise<ResumeRecord | undefined>;
  deleteResume(id: number): Promise<boolean>;
}

// DatabaseStorage implementation
export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }
  
  // Resume methods
  async getResume(id: number): Promise<ResumeRecord | undefined> {
    const [resume] = await db.select().from(resumes).where(eq(resumes.id, id));
    return resume || undefined;
  }
  
  async getResumesByUserId(userId: number): Promise<ResumeRecord[]> {
    return await db.select().from(resumes).where(eq(resumes.userId, userId));
  }
  
  async createResume(resume: InsertResume): Promise<ResumeRecord> {
    const [newResume] = await db
      .insert(resumes)
      .values(resume)
      .returning();
    return newResume;
  }
  
  async updateResume(id: number, data: Partial<Resume>): Promise<ResumeRecord | undefined> {
    const current = await this.getResume(id);
    if (!current) return undefined;
    
    const [updated] = await db
      .update(resumes)
      .set({ 
        data: data as any, // Type assertion for jsonb column
        updatedAt: new Date()
      })
      .where(eq(resumes.id, id))
      .returning();
    
    return updated;
  }
  
  async deleteResume(id: number): Promise<boolean> {
    const result = await db
      .delete(resumes)
      .where(eq(resumes.id, id))
      .returning({ id: resumes.id });
    
    return result.length > 0;
  }
}

export const storage = new DatabaseStorage();
