import OpenAI from "openai";

// The newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Function to generate title suggestions based on description
export async function suggestJobTitles(description: string): Promise<string[]> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a career advisor specialized in resume writing. Suggest 3 professional job titles based on the description provided."
        },
        {
          role: "user",
          content: `Based on this description, suggest 3 professional job titles: ${description}`
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.7,
    });

    const content = response.choices[0].message.content;
    if (!content) return [];
    
    const result = JSON.parse(content);
    return Array.isArray(result.titles) ? result.titles : [];
  } catch (error) {
    console.error("Failed to suggest job titles:", error);
    return [];
  }
}

// Function to suggest skills based on job title and experience
export async function suggestSkills(jobTitle: string, experience: string): Promise<Array<{name: string, level: number}>> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a career advisor helping professionals identify relevant skills for their resume. Suggest 5 relevant skills with proficiency levels (0-100)."
        },
        {
          role: "user",
          content: `Suggest 5 relevant skills with proficiency levels (as a number between 0-100) for a ${jobTitle} with the following experience: ${experience}`
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.7,
    });

    const content = response.choices[0].message.content;
    if (!content) return [];
    
    const result = JSON.parse(content);
    return Array.isArray(result.skills) ? result.skills : [];
  } catch (error) {
    console.error("Failed to suggest skills:", error);
    return [];
  }
}

// Function to correct grammar in text
export async function correctGrammar(text: string): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a professional editor. Correct grammar, spelling, and punctuation in the provided text without changing the meaning or adding content."
        },
        {
          role: "user",
          content: text
        }
      ],
      temperature: 0.3,
    });

    return response.choices[0].message.content || text;
  } catch (error) {
    console.error("Failed to correct grammar:", error);
    return text;
  }
}

// Function to optimize resume content (improve bullet points, highlight achievements, etc.)
export async function optimizeResume(resumeData: any): Promise<any> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are a professional resume consultant. Optimize the resume by improving descriptions, 
          highlighting achievements with metrics, and enhancing the professional summary. 
          Return the full optimized resume in JSON format matching the original structure exactly.`
        },
        {
          role: "user",
          content: `Optimize this resume: ${JSON.stringify(resumeData)}`
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.5,
    });

    const content = response.choices[0].message.content;
    if (!content) return resumeData;
    
    return JSON.parse(content);
  } catch (error) {
    console.error("Failed to optimize resume:", error);
    return resumeData;
  }
}